# Parcel Panic

A fast-paced delivery game where you draw routes for your truck to deliver packages to houses before time runs out!

## How to Play

- **Draw routes:** Click and drag to sketch delivery loops on the field
- **Commit routes:** Press Enter to close the loop and start delivery
- **Deliver to houses:** Drive near houses (cylindrical buildings) to deliver packages
- **Watch the timer:** Houses have circular countdown rings - deliver before they expire!
- **Controls:** Space to pause, T for 2× speed, R to redraw, G for grid, D for debug

## Game Features

- **3D Graphics:** Beautiful cylindrical houses with conical roofs
- **Timer System:** Visual countdown rings that change color (green → orange → red)
- **Progressive Difficulty:** 3 houses per week for weeks 1-5, then 5 houses per week
- **Upgrade System:** Choose upgrades between weeks to improve your delivery capabilities
- **Audio:** Immersive sound effects and background music
- **WebGPU Support:** High-performance rendering with WebGL fallback

## Technical Requirements

- Modern web browser with WebGL support
- JavaScript enabled
- Recommended: Chrome, Firefox, Safari, or Edge

## Credits

Built with Three.js, Vite, and modern web technologies.

Enjoy delivering packages in Parcel Panic! 🚚📦
